// for (let num =1; num<= 20; num++) {
//      console.log(num)
// }

// for (let num=100; num >=1; num--) {
//     if (num % 3 === 0)
//     console.log(num)
// }

for (let num = 4; num >= -4; num -= 1.5) {
    console.log(num)
}

// let sum = 0;

// for (let num = 1; num <=100; num++) {
//     sum += num;
//     console.log(sum)
//}

// let sum = 1;
// for (let num = 1; num<=12; num++) {
//     sum *= num;
//     console.log(sum)
// }